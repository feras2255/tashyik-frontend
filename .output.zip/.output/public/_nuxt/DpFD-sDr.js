import{$ as s}from"./D-q0Ojnq.js";const t=s("/images/tabby-tamara.webp");export{t as _};
