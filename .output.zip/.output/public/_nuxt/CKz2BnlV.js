import{aw as e}from"./D-q0Ojnq.js";function i(t){e(()=>import("./BCl_qhkn.js"),[],import.meta.url).then(o=>{t(o)})}export{i as u};
