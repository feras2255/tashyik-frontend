import{b as o}from"./D-q0Ojnq.js";function n(){o({robots:"noindex, follow",googlebot:"noindex, follow"})}export{n as u};
