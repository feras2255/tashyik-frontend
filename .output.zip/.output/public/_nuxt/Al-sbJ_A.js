import{$ as s}from"./BNyum9nz.js";const t=s("/images/tabby-tamara.webp");export{t as _};
