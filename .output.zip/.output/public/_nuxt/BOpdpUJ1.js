import{b as o}from"./BNyum9nz.js";function n(){o({robots:"noindex, follow",googlebot:"noindex, follow"})}export{n as u};
