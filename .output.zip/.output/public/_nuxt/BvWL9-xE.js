import{ay as e}from"./BNyum9nz.js";function i(t){e(()=>import("./BCl_qhkn.js"),[],import.meta.url).then(o=>{t(o)})}export{i as u};
