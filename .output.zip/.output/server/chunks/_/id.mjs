const id = {
  seo: {
    login: {
      title: "Masuk"
    },
    register: {
      title: "Buat Akun"
    },
    service_provider_register: {
      title: "Buat Akun Penyedia Jasa"
    },
    orders: {
      title: "Pesanan Saya",
      view: {
        title: "Detail Pesanan"
      }
    },
    addresses: {
      title: "Alamat Saya",
      create: {
        title: "Tambah Alamat Baru"
      },
      edit: {
        title: "Ubah Alamat"
      }
    },
    profile: {
      title: "Profil Pribadi"
    },
    forgot_password: {
      title: "Lupa Kata Sandi"
    },
    reset_password: {
      title: "Reset Kata Sandi"
    },
    service_provider: {
      title: "Bergabunglah sebagai Teknisi",
      description: "Daftar sebagai penyedia jasa rumah tangga dan tawarkan layanan AC, listrik, pipa air, peralatan rumah tangga, pertukangan, pengecatan, satelit, pembersihan, pengendalian hama, dan bantuan rumah tangga dengan mudah dan aman."
    },
    categories: {
      title: "Kategori",
      description: "Jelajahi kategori layanan perawatan rumah, termasuk pipa air, listrik, AC, dan perbaikan peralatan rumah tangga. Pesan teknisi rumah bersertifikat dengan cepat dan kualitas terjamin."
    },
    services: {
      title: "Layanan",
      description: "Jelajahi semua layanan perawatan rumah, cari layanan yang Anda butuhkan, dan pesan teknisi bersertifikat dengan cepat."
    },
    cities_index: {
      title: "Kota yang kami layani",
      description: "Jelajahi cakupan perawatan rumah di kota-kota Saudi dan buka halaman layanan lokal untuk wilayah Anda."
    },
    about: {
      title: "Tentang Kami",
      description: "Platform Saudi yang khusus menghubungkan Anda dengan teknisi bersertifikat untuk semua layanan perawatan rumah, dengan cepat, aman, dan mudah. Tujuan kami adalah memberikan ketenangan pikiran dan memastikan kualitas rumah Anda."
    },
    contact: {
      title: "Hubungi Kami",
      description: "Tim kami siap menerima pesan Anda dan merespons secepat mungkin. Isi detailnya, dan kami akan langsung menghubungi Anda untuk membantu atau memenuhi permintaan Anda."
    },
    home: {
      title: "Tashyik | Pesan teknisi perawatan rumah bersertifikat di Arab Saudi",
      description: "Pesan teknisi terpercaya untuk AC, pipa, listrik, dan perbaikan peralatan di setiap kota Saudi. Layanan cepat, garansi bersertifikat, harga transparan."
    }
  },
  a11y: {
    open_user_menu: "Buka menu pengguna",
    open_main_menu: "Buka menu utama",
    close_menu: "Tutup menu",
    notifications: "Notifikasi",
    language: "Bahasa",
    breadcrumb: "Navigasi jalur",
    contact_whatsapp: "Hubungi via WhatsApp",
    coupon_code: "Kode kupon",
    show_password: "Show password",
    hide_password: "Hide password",
    chatbot: "Open chat"
  },
  common: {
    maintenance: "Pemeliharaan",
    brand: "Tashyik",
    account: "Akun",
    next: "Selanjutnya",
    back: "Kembali",
    short_description: "Layanan Perawatan Rumah",
    order_service: "Pesan Layanan",
    load_more: "Muat Lebih Banyak",
    save: "Simpan",
    select_type: "Pilih Tipe",
    select_categories: "Pilih Kategori",
    individual: "Individu",
    institution: "Institusi",
    company: "Perusahaan",
    update: "Perbarui",
    delete: "Hapus",
    updated_successfully: "Berhasil Diperbarui",
    page_not_found: "Halaman Tidak Ditemukan",
    something_went_wrong: "Terjadi kesalahan",
    or: "Atau",
    request_under_review: "Permintaan Anda sedang ditinjau",
    back_to_home: "Kembali ke Beranda",
    no_price: "Harga sesuai kesepakatan",
    select_city: "Pilih Kota",
    search_for_services: "Cari layanan...",
    search: "Cari",
    promotion: "Diskon {percentage}%",
    warranty: "Garansi selama {duration}",
    all: "Semua",
    wallet_balance: "Saldo Dompet",
    optional: "Opsional",
    select_address: "Pilih Alamat",
    done: "Selesai",
    loading: "Memuat\u2026",
    order_now: "Pesan Sekarang",
    send: "Kirim",
    close: "Tutup"
  },
  alt: {
    category: "Kategori {category}",
    service: "Layanan {service}"
  },
  home: {
    hero: {
      title: "Tashyik kini hadir di Arab Saudi!",
      subtitle: {
        part_1: "Kami di sini",
        part_2: "Untuk mempermudah hidup Anda",
        part_3: "Semua layanan rumah Anda di satu tempat"
      },
      search_placeholder: "Layanan apa yang Anda butuhkan?",
      search_button: "Cari Sekarang",
      rating_badge: "Peringkat Pelanggan 4.9",
      response_badge: "Respons dalam hitungan menit",
      technicians_badge: "500+ Teknisi Bersertifikat",
      highlight_1: "Teknisi Bersertifikat",
      highlight_2: "Respon dalam hitungan menit",
      description: "Kami menyediakan layanan perawatan rumah terintegrasi yang diantarkan ke depan pintu Anda dengan cepat dan mudah.",
      actions: {
        browse_categories: "Lihat Kategori",
        request_custom_service: "Minta Layanan Khusus"
      }
    },
    categories: {
      title: "Semua yang Anda butuhkan ada di sini!",
      action: "Lihat Semua Kategori",
      huge_discounts: "Diskon Besar"
    },
    offers: {
      title: "Penawaran Eksklusif Waktu Terbatas",
      description: "Manfaatkan diskon terbaik untuk layanan pemeliharaan rumah dengan teknisi profesional terbaik.",
      free_inspection: "Inspeksi Gratis",
      discount_on_service: "Diskon {percentage}% untuk {name}",
      free_inspection_for: "Inspeksi Gratis untuk {name}",
      first_order_maintenance: "Pemeliharaan peralatan rumah tangga dari pesanan pertama",
      plumbing_saving: "Penghematan pipa ledeng"
    },
    top_rated: {
      title: "Peringkat Teratas",
      provider_1: {
        name: "Teknisi AC Teratas",
        title: "Spesialis AC"
      },
      provider_2: {
        name: "Teknisi Listrik Teratas",
        title: "Spesialis Perbaikan Listrik"
      },
      provider_3: {
        name: "Teknisi Peralatan Teratas",
        title: "Spesialis Perbaikan Peralatan"
      }
    },
    features: {
      title: "Mengapa memilih Tashyik?",
      fast_support: {
        title: "Dukungan Cepat",
        description: "Tim dukungan kami tersedia 24/7 untuk menjawab pertanyaan Anda dan menyelesaikan masalah Anda."
      },
      clear_prices: {
        title: "Harga Jelas",
        description: "Tidak ada biaya tersembunyi \u2014 harga ditetapkan di muka sehingga Anda tahu biayanya sebelum memesan."
      },
      trusted_techs: {
        title: "Teknisi Terpercaya",
        description: "Semua teknisi menjalani pemeriksaan latar belakang menyeluruh dan pengujian keterampilan profesional."
      },
      instant_booking: {
        title: "Pemesanan Instan",
        description: "Hanya dengan beberapa klik, teknisi Anda sedang dalam perjalanan ke rumah Anda pada waktu yang disepakati."
      },
      real_reviews: {
        title: "Ulasan Nyata",
        description: "Semua peringkat berasal dari pelanggan nyata yang telah benar-benar merasakan layanan ini."
      },
      warranty: {
        title: "Garansi Layanan",
        description: "Kami memberikan garansi hingga 30 hari untuk semua layanan pemeliharaan yang telah diselesaikan."
      }
    },
    newsletter: {
      title: "Jangan lewatkan penawaran baru!",
      description: "Berlangganan buletin kami untuk menerima diskon terbaru dan penawaran eksklusif langsung ke kotak masuk Anda.",
      placeholder: "Alamat email Anda",
      subscribe: "Berlangganan"
    },
    collections: {
      view_all: "Lihat semua layanan",
      season_badge: "Penawaran musim"
    },
    reviews: {
      title: "Apa kata pelanggan kami!",
      item_1: {
        name: "\u0641\u0647\u062F \u0627\u0644\u0639\u0646\u0632\u064A",
        tag: "Pemeliharaan",
        body: "Aplikasi luar biasa! Saya memesan teknisi AC dan dia datang dalam waktu satu jam. Kerjanya bersih dan harganya sangat wajar. Sangat direkomendasikan! \u{1F44D}",
        date: "Seminggu yang lalu"
      },
      item_2: {
        name: "Sarah Al-Qahtani",
        tag: "Pemeliharaan",
        body: "Pengalaman yang luar biasa! Saya menghubungi dukungan pemeliharaan dan mendapat respon cepat serta bantuan yang sangat baik. Layanan melebihi ekspektasi!",
        date: "Dua hari yang lalu"
      },
      item_3: {
        name: "Mohammed Al-Sulaimani",
        tag: "Pemeliharaan",
        body: "Aplikasi yang istimewa, teknisinya profesional dan cepat. Saya memperbaiki AC saya dalam waktu kurang dari dua jam.",
        date: "Kemarin"
      },
      item_4: {
        name: "Nasser Al-Otaibi",
        tag: "Pemeliharaan Listrik",
        body: "Pekerjaan profesional dan waktu yang tepat. Teknisi menjelaskan masalah dengan jelas dan menyelesaikan layanan dengan cepat sambil menjaga kebersihan tempat. Terima kasih!",
        date: "Tiga hari yang lalu"
      }
    },
    questions: {
      title: "Pertanyaan yang mungkin Anda miliki!"
    }
  },
  download_app: {
    title_1: "Semua layanan rumah Anda sekarang..",
    title_2: "dalam satu aplikasi!",
    title: "Semua layanan rumah Anda.. dalam satu aplikasi!",
    subtitle: "Unduh aplikasinya dan pesan layanan yang Anda butuhkan kapan saja dengan kenyamanan penuh, semua dari ponsel Anda hanya dengan satu klik.",
    get_it_on: "Dapatkan di",
    download_on_the: "Unduh di",
    highlight_1: "Pesan layanan dalam hitungan detik",
    highlight_2: "Pembayaran aman dan terjamin",
    highlight_3: "Lacak teknisi secara real-time"
  },
  footer: {
    important_links: "Tautan Penting",
    privacy_policy: "Kebijakan Privasi",
    terms_and_conditions: "Syarat & Ketentuan",
    faq: "FAQ",
    contact_us_link: "Hubungi Kami",
    copyright: "Seluruh hak cipta dilindungi undang-undang",
    developed_by: "Dijalankan oleh",
    developer: "Pengembang",
    contact_us: {
      title: "Hubungi Kami",
      support: "Dukungan pelanggan tersedia 24/7"
    },
    resources: "Tautan Penting",
    download_app: "Unduh Aplikasi",
    saudi_business_center: "Terverifikasi di Platform Bisnis",
    popular_services: "Layanan populer",
    popular_cities: "Kota populer",
    see_all_services: "Lihat semua layanan",
    see_all_cities: "Lihat semua kota"
  },
  navigation: {
    home: "Beranda",
    login: "Masuk",
    register: "Daftar",
    about: "Tentang Kami",
    categories: "Kategori",
    services: "Layanan",
    download_app: "Unduh Aplikasi",
    contact: "Hubungi Kami",
    articles: "Artikel",
    cities: "Kota",
    logout: "Keluar",
    privacy_policy: "Kebijakan Privasi",
    terms_and_conditions: "Syarat dan Ketentuan",
    service_provider: "Daftar sebagai Penyedia Jasa",
    profile: {
      title: "Akun Saya",
      subtitle: "Kelola informasi pribadi Anda"
    },
    orders: {
      title: "Pesanan Saya",
      subtitle: "Lacak pesanan dan pembelian Anda"
    },
    addresses: {
      title: "Alamat Saya",
      subtitle: "Kelola alamat yang tersimpan"
    },
    institution_members: {
      title: "Kelola Karyawan",
      subtitle: "Lihat dan kelola karyawan institusi"
    }
  },
  guest: {
    login: {
      title: "Selamat Datang!",
      subtitle: "Masuk dan selesaikan permintaan Anda dengan mudah.",
      forgot_password: "Lupa kata sandi?",
      sign_in: "Masuk",
      sign_up: "Buat Akun Baru",
      no_account: "Belum punya akun?"
    },
    register: {
      customer: {
        title: "Buat Akun Baru",
        subtitle: "Buat akun Anda dan pesan layanan dengan mudah."
      },
      service_provider: {
        title: "Buat Akun Anda Sekarang",
        subtitle: "Daftar sebagai teknisi dan mulailah menerima permintaan perawatan rumah sekarang.",
        applied: {
          title: "Berhasil Terdaftar",
          subtitle: "Permintaan pendaftaran Anda sedang dalam peninjauan."
        }
      },
      title: "Buat Akun Baru",
      create_account: "Buat Akun",
      have_account: "Sudah punya akun?",
      sign_in: "Masuk"
    },
    forgot_password: {
      title: "Lupa Kata Sandi?",
      subtitle: "Masukkan email Anda dan kami akan mengirimkan kode verifikasi.",
      send_otp: "Kirim Kode Verifikasi",
      otp_subtitle: "Masukkan kode verifikasi yang dikirim ke email Anda.",
      otp_label: "Kode Verifikasi",
      verify_otp: "Verifikasi Kode",
      resend_otp: "Kirim Ulang Kode",
      success_message: "Kode verifikasi telah dikirim ke email Anda.",
      back_to_login: "Kembali ke Halaman Masuk"
    },
    reset_password: {
      title: "Reset Kata Sandi",
      subtitle: "Masukkan kata sandi baru Anda.",
      reset_button: "Reset Kata Sandi",
      success_message: "Kata sandi berhasil direset. Anda sekarang dapat masuk dengan kata sandi baru."
    }
  },
  inputs: {
    email: "Email",
    email_optional: "Email (Opsional)",
    name: "Siapa nama Anda?",
    phone: "Nomor Telepon",
    password: "Kata Sandi",
    current_password: "Kata Sandi Saat Ini",
    new_password: "Kata Sandi Baru",
    password_confirmation: "Konfirmasi Kata Sandi",
    remember_me: "Ingat Saya",
    city: "Di mana Anda tinggal?",
    entity_type: "Tipe Akun",
    categories: "Kategori",
    residence_name: "Nama sesuai KTP/Iqama",
    residence_number: "Nomor KTP/Iqama",
    residence_image: "Salinan KTP/Iqama",
    commercial_registration_number: "Nomor CR (NIB)",
    commercial_registration_image: "Salinan CR (NIB)",
    bank_name: "Nama Bank",
    iban: "IBAN",
    personal_picture: "Foto Profil",
    national_address_image: "Salinan Alamat Nasional",
    tax_registration_number: "Nomor NPWP",
    address: {
      title: "Alamat",
      placeholder: "Contoh: Riyadh Al Saliheen St, Mansoura, Riyadh"
    },
    type_address_name: {
      title: "Nama Alamat",
      placeholder: "Contoh: Rumah Baru"
    },
    landmark: {
      title: "Patokan Terdekat",
      placeholder: "Contoh: Dekat pom bensin"
    },
    address_name: "Nama Alamat",
    building_number: "Nomor Gedung",
    floor_number: "Nomor Lantai",
    apartment_number: "Nomor Apartemen"
  },
  services: {
    index_eyebrow: "Semua layanan",
    index_title: "Temukan layanan rumah yang tepat",
    index_subtitle: "Cari layanan Tashyik, filter berdasarkan spesialisasi, dan pesan teknisi bersertifikat tanpa membuka kategori terlebih dahulu.",
    index_support_title: "Butuh bantuan memilih layanan?",
    index_search_label: "Cari layanan",
    index_search_placeholder: "Cari berdasarkan nama layanan, masalah, atau kata kunci...",
    index_filter_by_category: "Filter berdasarkan kategori",
    index_result_count: "Menampilkan {count} dari {total} layanan",
    index_clear_filters: "Hapus filter",
    empty: {
      title: "Layanan tidak ditemukan",
      subtitle: "Coba ubah kategori atau kata kunci pencarian untuk melihat lebih banyak layanan"
    },
    invoice: {
      title: "Lihat Faktur",
      service: "Layanan",
      service_price: "Harga Layanan",
      visit_cost: "Biaya Kunjungan",
      subtotal: "Subtotal",
      tax: "Pajak",
      wallet_balance: "Saldo Dompet",
      total: "Total",
      pay: "Bayar",
      request: "Pesan Layanan"
    },
    custom_service: {
      title: "Tidak yakin dengan layanan yang tepat?",
      subtitle: "Tidak menemukan apa yang Anda butuhkan? Jangan khawatir! Jelaskan masalahnya, dan Anda akan menerima penawaran dari teknisi ahli.",
      action: "Minta Layanan Khusus"
    }
  },
  orders: {
    name: "Pesanan Saya",
    navigation: {
      new: "Baru",
      in_progress: "Sedang Berjalan",
      completed: "Selesai"
    },
    empty: {
      title: "Tidak ada pesanan",
      subtitle: "Pesanan tidak ditemukan",
      view_services: "Pesan layanan sekarang"
    },
    make: {
      title: "Pesan Layanan",
      address: "Alamat Layanan",
      details: {
        title: "Detail Layanan",
        description: "Deskripsi masalah..."
      },
      coupons: {
        title: "Punya kode promo?",
        placeholder: "Masukkan kode promo",
        apply: "Gunakan"
      },
      summary: {
        title: "Ringkasan Pesanan"
      }
    }
  },
  notifications: {
    title: "Notifikasi",
    no_notifications: "Tidak ada notifikasi"
  },
  addresses: {
    title: "Alamat Saya",
    heading: {
      title: "Alamat Tersimpan Saya",
      subtitle: "Kelola alamat terdaftar atau tambah alamat baru untuk memesan layanan dengan cepat",
      action: "Tambah Alamat Baru"
    },
    new: {
      title: "Tambah Alamat Baru",
      subtitle: "Tentukan lokasi Anda di peta agar teknisi lebih mudah mencapai lokasi Anda"
    },
    create: {
      title: "Tambah Alamat",
      heading: {
        title: "Tambah Alamat Baru",
        subtitle: "Silakan pilih lokasi Anda di peta dan lengkapi detailnya"
      },
      save: "Konfirmasi Simpan Alamat"
    },
    edit: {
      title: "Ubah Alamat",
      heading: {
        title: "Ubah Alamat",
        subtitle: "Silakan pilih lokasi Anda di peta dan lengkapi detailnya"
      },
      save: "Perbarui Alamat"
    },
    form: {
      title: "Detail Alamat",
      options: {
        home: "Rumah",
        work: "Kantor",
        other: "Lainnya"
      }
    }
  },
  address: {
    details: "Gedung {building_number}, No. {apartment_number}, Lantai {floor_number}",
    mark_as_default: "Jadikan Alamat Utama"
  },
  profile: {
    name: "Profil",
    header: {
      title: "Pengaturan Profil",
      subtitle: "Ubah pengaturan profil, foto, dan kata sandi Anda."
    },
    information: "Informasi Profil",
    linked_institution: "Works at",
    update_password: "Perbarui Kata Sandi",
    delete_account: "Hapus Akun"
  },
  service_provider: {
    h1: {
      title: "Daftar sebagai teknisi AC, Listrik, Pipa, dan lainnya",
      description: "Apakah Anda memiliki keahlian dalam layanan rumah dan mencari cara mudah untuk menjangkau pelanggan? Bergabunglah dengan kami dan mulailah memberikan layanan Anda dengan percaya diri dan profesional melalui platform khusus kami."
    },
    h2: {
      title: "Berikan layanan Anda sekarang",
      description: "Kami menyambut semua teknisi dan penyedia layanan rumah di bidang berikut:",
      items: [
        "AC (Pemasangan \u2013 Perawatan \u2013 Pembersihan)",
        "Listrik (Kabel \u2013 Perbaikan \u2013 Pemasangan Alat)",
        "Pipa Air (Perawatan \u2013 Deteksi Kebocoran \u2013 Ekstensi)",
        "Peralatan Rumah (Mesin Cuci \u2013 Kulkas \u2013 Oven \u2013 Microwave)",
        "Pertukangan (Pintu \u2013 Furnitur \u2013 Kamar Tidur \u2013 Custom)",
        "Pengecatan (Interior & Eksterior \u2013 Wallpaper)",
        "Satelit/Parabola (Pemasangan \u2013 Pemrograman \u2013 Perawatan)",
        "Pembersihan Rumah (Pembersihan Menyeluruh \u2013 Karpet)",
        "Pengendalian Hama (Pestisida Aman dan Efektif)",
        "Bantuan Rumah Tangga (Membersihkan, Merapikan, dan Dukungan Harian)"
      ]
    },
    button: "Daftar Sekarang"
  },
  categories: {
    title: "Semua layanan perawatan yang dibutuhkan rumah Anda",
    subtitle: "Pilih layanan yang tepat dan pesan teknisi bersertifikat dengan mudah kapan saja.",
    banner: {
      title: "Siap memulai pengalaman Anda dengan Tashyik?",
      subtitle: "Unduh aplikasi Tashyik sekarang dan dapatkan layanan perawatan pertama Anda dengan mudah dan profesional."
    }
  },
  cities: {
    hero_title: "Layanan Tashyik",
    hero_h1_maintenance: "Layanan perawatan rumah",
    hero_compact_subtitle: "Cepat, tepercaya, tersedia di kota Anda",
    hero_subtitle: "Pesan layanan dari ahli terverifikasi",
    browse_services: "Jelajahi layanan",
    schema_description: "Platform profesional untuk layanan rumah terpercaya",
    popular_services: "Layanan populer di kota ini",
    available_in: "Tersedia di {city}",
    index_title: "Kota yang kami layani",
    index_subtitle: "Pilih kota untuk melihat layanan perawatan rumah populer dan memesan teknisi bersertifikat.",
    service_links_truncated: "Buka untuk melihat layanan lainnya",
    view_city_hub: "Lihat pusat kota",
    browse_by_city: "Jelajahi berdasarkan kota",
    services_heading: "Semua layanan",
    services_search_label: "Cari layanan",
    services_search_placeholder: "Ketik nama layanan",
    city_search_result_count: "{count} hasil di {city}",
    city_search_no_results_for: 'Tidak ada hasil untuk "{q}"',
    city_categories_filter_aria: "Filter kategori",
    districts_heading: "Wilayah utama di {city}",
    districts_intro: "Kami melayani wilayah utama {city} dengan waktu kedatangan tercepat.",
    services_results_range: "Menampilkan {shown} dari {total} ({filtered} difilter)",
    services_no_results: "Layanan tidak ditemukan",
    services_none_in_city: "Belum ada layanan di kota ini",
    pagination_label: "Navigasi halaman",
    pagination_prev: "Sebelumnya",
    pagination_next: "Berikutnya",
    hero_cta_app: "Unduh aplikasi",
    hero_cta_call: "Telepon sekarang",
    price_currency: "SAR",
    index_browse_categories: "Jelajahi kategori",
    index_filter_placeholder: "Filter kategori",
    index_card_subtitle: "Layanan cepat dan tepercaya",
    index_secondary_hint: "Pilih sesuai kebutuhan Anda",
    index_filter_no_match: "Tidak ada kategori yang cocok",
    service_in_city_cta_order: "Pesan layanan",
    service_in_city_cta_order_now: "Pesan sekarang",
    service_in_city_whatsapp_cta: "Pesan via WhatsApp",
    service_in_city_trust_secure_pay: "Pembayaran aman terjamin",
    service_in_city_certified_badge: "Profesional tersertifikasi",
    service_in_city_rating_line: "Rating {rating} dari {orders} pesanan",
    service_in_city_rating_with_orders: "{rating} ({orders} pesanan)",
    service_in_city_social_hint: "Dipercaya oleh ribuan pelanggan",
    service_in_city_includes_title: "Termasuk dalam layanan ini",
    service_in_city_local_overview: "Tinjauan lokal untuk {city}",
    service_in_city_how_title: "Cara kerjanya",
    service_in_city_how_step1: "Pesan",
    service_in_city_how_step1_desc: "Pilih layanan dan jadwal",
    service_in_city_how_step2: "Penugasan ahli",
    service_in_city_how_step2_desc: "Ahli terverifikasi akan ditugaskan untuk Anda",
    service_in_city_how_step3: "Pekerjaan selesai",
    service_in_city_how_step3_desc: "Bayar aman setelah pekerjaan selesai",
    service_in_city_why_title: "Mengapa memilih kami",
    service_in_city_why_1_title: "Tim terverifikasi",
    service_in_city_why_1_desc: "Setiap teknisi diperiksa dan dilatih",
    service_in_city_why_2_title: "Datang tepat waktu",
    service_in_city_why_2_desc: "Layanan hadir sesuai jadwal",
    service_in_city_why_3_title: "Harga transparan",
    service_in_city_why_3_desc: "Tanpa biaya tersembunyi",
    service_in_city_why_4_title: "Dukungan berkualitas",
    service_in_city_why_4_desc: "Bantuan tetap tersedia setelah layanan",
    service_in_city_reviews_title: "Ulasan pelanggan",
    service_in_city_rev1_name: "Rafi Pratama",
    service_in_city_rev1_text: "Layanannya sangat bagus dan tim datang tepat waktu.",
    service_in_city_rev2_name: "Nadia Putri",
    service_in_city_rev2_text: "Pemesanan mudah dan hasilnya memuaskan.",
    service_in_city_rev3_name: "Ilham Saputra",
    service_in_city_rev3_text: "Profesional dan harganya masuk akal.",
    service_in_city_default_bullet1: "Respon cepat",
    service_in_city_default_bullet2: "Ahli berpengalaman",
    service_in_city_default_bullet3: "Jaminan layanan",
    service_in_city_related_title: "Layanan terkait",
    service_in_city_sidebar_summary: "Layanan tepercaya di kota Anda",
    service_in_city_price_label: "From"
  },
  service: {
    order_service: "Pesan Layanan Sekarang",
    actions: {
      order_now: "Pesan Sekarang!",
      view_details: "Lihat Detail"
    },
    highlight_1: "Teknisi Bersertifikat dan Spesialis",
    highlight_2: "Pembayaran Aman",
    highlight_3: "Kualitas Terjamin",
    highlights: {
      title: "Apa yang akan kami lakukan untuk Anda?"
    }
  },
  order: {
    id: "Nomor Pesanan",
    title: "Detail Pesanan",
    actions: {
      view_details: "Lihat Detail Pesanan",
      rate: "Beri rating pengalaman Anda",
      order_again: "Pesan Lagi",
      cancel: {
        title: "Batal dan Pengembalian Dana",
        description: "Anda harus menunggu 15 menit sebelum dapat membatalkan pesanan"
      }
    },
    summary: {
      title: "Ringkasan Pesanan",
      service: "Layanan",
      quantity: "Jumlah",
      date: "Tanggal Pesanan",
      status: "Status",
      description: "Deskripsi Masalah",
      visit_cost: "Biaya Kunjungan",
      subtotal: "Subtotal",
      tax: "Pajak ({rate}%)",
      wallet_balance: "Saldo Dompet",
      total: "Jumlah Pembayaran",
      pay: "Bayar Sekarang",
      confirm: "Konfirmasi"
    },
    status: {
      title: "Status Pesanan",
      new: "Ditampilkan ke teknisi",
      confirmed: "Dikonfirmasi",
      on_the_way: "Teknisi dalam perjalanan",
      arrived: "Teknisi telah sampai",
      started: "Pengerjaan sedang berlangsung",
      completed: "Selesai"
    },
    service_provider: {
      title: "Teknisi",
      phone: "Telepon",
      actions: {
        view_on_map: "Lihat di Peta",
        call: "Hubungi Teknisi",
        whatsapp: "Kirim Pesan WhatsApp"
      }
    },
    invoice: {
      title: "Detail Faktur",
      price: "Harga Layanan",
      tax: "PPN ({rate}%)",
      total: "Total",
      view_details: "Lihat Detail",
      hide_details: "Sembunyikan Detail",
      visit_cost: "Biaya Kunjungan",
      coupons: "Kode Promo",
      wallet_balance: "Saldo Dompet"
    },
    canceled: {
      title: "Pesanan Dibatalkan",
      subtitle: "Dana telah dikembalikan ke saldo dompet Anda"
    },
    extra: {
      title: "Layanan Tambahan",
      unpaid: "Belum Dibayar",
      paid: "Sudah Dibayar",
      view_details: "Lihat Detail",
      invoice: {
        title: "Detail Layanan Tambahan",
        price: "Harga Layanan Tambahan",
        tax: "Pajak Layanan Tambahan",
        materials: "Harga Material"
      }
    }
  },
  review: {
    title: "Rating Layanan",
    price: "Biaya",
    rate: "Bagaimana pengalaman Anda secara keseluruhan?",
    notes: "Tulis catatan Anda (opsional)",
    notes_placeholder: "Tulis saran atau masukan Anda di sini...",
    actions: {
      send: "Kirim Rating",
      skip: "Lewati"
    }
  },
  about: {
    hero: {
      title: "Tashyik \u2013 Melayani Anda dengan profesional",
      description: "Platform Saudi yang khusus menghubungkan Anda dengan teknisi bersertifikat untuk semua layanan perawatan rumah, dengan cepat, aman, dan mudah. Tujuan kami adalah memberikan ketenangan pikiran dan memastikan kualitas rumah Anda.",
      subtitle: {
        part_1: "Siapa",
        part_2: "Kami?"
      },
      actions: {
        discover: "Temukan Cerita Kami"
      },
      highlight: {
        title: "Keandalan Penuh",
        subtitle: "Teknisi dengan ID Terverifikasi"
      }
    },
    story: {
      title: "Cerita Kami",
      paragraph_1: "Kami memulai Tashyik dengan tujuan mempermudah hidup orang-orang dan memberikan solusi cerdas yang mengumpulkan semua layanan perawatan rumah dalam satu tempat. Kami percaya bahwa layanan yang cepat dan andal dimulai dengan memilih teknisi yang tepat dan diakhiri dengan kepuasan pelanggan.",
      paragraph_2: "Visi kami melampaui sekadar memperbaiki kerusakan; kami berupaya membangun komunitas teknis Saudi yang berkontribusi dalam meningkatkan kualitas hidup di setiap rumah di Kerajaan, dengan mengatur layanan perawatan melalui satu aplikasi sambil meningkatkan standar profesional."
    },
    features: {
      title: {
        part_1: "Mengapa memilih",
        part_2: "Tashyik?"
      },
      subtitle: "Kami bukan sekadar aplikasi perawatan! Kami adalah mitra tepercaya untuk perawatan rumah Anda.",
      feature_1: {
        title: "Teknisi Bersertifikat",
        description: "Kami memilih teknisi dengan cermat dan meninjau kinerja mereka secara konsisten untuk memastikan tingkat kualitas tertinggi."
      },
      feature_2: {
        title: "Respon Cepat",
        description: "Teknisi terdekat mencapai lokasi Anda dalam waktu singkat untuk menyelesaikan masalah secepat mungkin."
      },
      feature_3: {
        title: "Pembayaran Aman",
        description: "Metode pembayaran tepercaya dan terlindungi dengan standar keamanan elektronik terbaru."
      },
      feature_4: {
        title: "Pelacakan Real-time",
        description: "Ikuti status pesanan Anda langkah demi langkah melalui aplikasi dengan transparansi penuh."
      }
    },
    stats_1: {
      title: "3.800+",
      subtitle: "Teknisi Profesional Bersertifikat"
    },
    stats_2: {
      title: "632.000+",
      subtitle: "Pesanan Berhasil Diselesaikan"
    },
    stats_3: {
      title: "4.8",
      subtitle: "Rating Kepuasan Pelanggan"
    },
    audience: {
      title: "Siapa yang kami layani?",
      subtitle: "Baik Anda membutuhkan perawatan cepat, pemasangan, atau perbaikan, Tashyik melayani dan menyesuaikan dengan kebutuhan Anda.",
      individuals: {
        title: "Pemilik Rumah",
        description: "Kami melayani pemilik rumah yang menginginkan ketenangan pikiran dan tidak memiliki waktu untuk mencari teknisi. Melalui platform kami, Anda dapat memesan layanan dengan mudah, dan kami menghubungkan Anda dengan teknisi andal yang menyelesaikan pekerjaan secara profesional dan tepat waktu."
      },
      institutions: {
        title: "Institusi/Lembaga",
        description: "Kami tahu bahwa kerusakan kecil sekalipun dapat memengaruhi alur kerja. Itulah sebabnya kami menyediakan solusi perawatan untuk institusi guna menjaga kelangsungan bisnis tanpa gangguan."
      },
      service_providers: {
        title: "Teknisi",
        description: "Kami percaya teknisi adalah jantung dari layanan ini. Kami menyediakan platform yang membantu mereka menjangkau pelanggan asli, organisasi pesanan yang jelas, dan dukungan yang memudahkan pekerjaan harian mereka."
      }
    }
  },
  contact: {
    title: "Hubungi Kami Langsung",
    subtitle: "Tim kami siap melayani dan menjawab semua pertanyaan Anda",
    hero: {
      title: "Selamat datang! Bagaimana kami bisa membantu?",
      description: "Tim kami siap menerima pesan Anda dan merespons secepat mungkin. Isi detailnya, dan kami akan langsung menghubungi Anda."
    },
    inputs: {
      name: {
        title: "Nama Lengkap",
        placeholder: "Masukkan nama lengkap Anda"
      },
      subject: {
        title: "Apa yang ingin Anda bicarakan?",
        placeholder: "Pemeliharaan, pertanyaan, keluhan, atau lainnya"
      },
      message: {
        title: "Beri tahu kami apa yang ada di pikiran Anda!",
        placeholder: "Tulis pesan Anda di sini dan kami akan merespons sesegera mungkin..."
      }
    },
    actions: {
      send: "Kirim Pesan Anda"
    },
    info: {
      whatsapp: "Hubungi kami via WhatsApp",
      phone: "Telepon kami segera",
      email: "Email kami"
    },
    more_info: {
      title: "Cakupan Luas",
      subtitle: "Melayani Anda di seluruh wilayah Arab Saudi dengan profesionalisme penuh!"
    },
    map: {
      title: "Lokasi Kami",
      subtitle: "Kunjungi kantor pusat kami di Riyadh"
    },
    message_sent: "Berhasil Terkirim"
  },
  articles: {
    seo: {
      title: "Artikel - Tashyik",
      description: "Baca artikel terbaru dan dapatkan tips tentang perawatan rumah, perawatan peralatan rumah tangga, dan praktik terbaik untuk menjaga rumah Anda."
    },
    hero: {
      title: "Artikel",
      subtitle: "Tips dan informasi bermanfaat mengenai perawatan rumah dan cara menjaga rumah Anda."
    },
    featured_badge: "Artikel Unggulan",
    read_more: "Baca selengkapnya",
    share: "Bagikan Artikel",
    empty: "Tidak ada artikel yang tersedia saat ini.",
    related: "Artikel Terkait"
  },
  institution: {
    title: "Kelola Karyawan",
    subtitle: "View performance and statistics of institution employees",
    seo_title: "Layanan rumah profesional di {city}",
    summary: {
      active_members: "Active Employees",
      this_month_orders: "Orders This Month",
      this_month_earnings: "Earnings This Month",
      balance: "Current Balance"
    },
    member: {
      total_orders: "Total Orders",
      completed_orders: "Completed Orders",
      this_month: "This Month",
      earnings: "Earnings",
      joined: "Joined"
    },
    empty: {
      title: "No employees",
      subtitle: "No employees have been added to the institution yet."
    },
    status: {
      active: "Active",
      pending: "Pending",
      inactive: "Inactive"
    },
    filter: {
      all: "All",
      search: "Search by name or phone...",
      results: "{count} results",
      no_results: "No results found",
      clear: "Clear filters"
    },
    sort: {
      name: "Sort by name",
      earnings: "Highest earnings",
      orders: "Most orders",
      this_month: "Most active this month"
    }
  },
  chatbot: {
    title: "Tashyik Chat",
    subtitle: "We are here to help you",
    welcome: "Welcome! How can we help you?",
    placeholder: "Type your message...",
    new_chat: "New Chat",
    send: "Kirim",
    close: "Tutup",
    typing: "Typing...",
    error_network: "Unable to connect. Please check your connection and try again.",
    error_server: "Server error occurred. Please try again later.",
    error_generic: "An unexpected error occurred. Please try again.",
    retry: "Try again",
    messages_count: "messages",
    suggestion_1: "Contoh: Bisakah saya memesan layanan teknisi listrik cepat?",
    suggestion_2: "Contoh: Bagaimana cara saya meminta layanan perawatan AC?"
  }
};

export { id as default };
//# sourceMappingURL=id.mjs.map
