const en = {
  seo: {
    login: {
      title: "Login"
    },
    register: {
      title: "Create Account"
    },
    service_provider_register: {
      title: "Create Service Provider Account"
    },
    orders: {
      title: "My Orders",
      view: {
        title: "Order Details"
      }
    },
    addresses: {
      title: "My Addresses",
      create: {
        title: "Add New Address"
      },
      edit: {
        title: "Edit Address"
      }
    },
    profile: {
      title: "Profile"
    },
    forgot_password: {
      title: "Forgot Password"
    },
    reset_password: {
      title: "Reset Password"
    },
    service_provider: {
      title: "Join Us as a Technician",
      description: "Register as a home service provider and offer AC, electricity, plumbing, home appliances, carpentry, painting, satellite, cleaning, pest control, and home assistance services easily and securely."
    },
    categories: {
      title: "Categories",
      description: "Browse home maintenance categories, including plumbing, electricity, AC, and home appliance repair. Book a guaranteed home technician quickly."
    },
    services: {
      title: "Services",
      description: "Browse all home maintenance services, search for the service you need, and book a certified technician quickly."
    },
    cities_index: {
      title: "Cities we serve",
      description: "Browse trusted home maintenance coverage in Saudi cities and open localized service pages for your area."
    },
    about: {
      title: "About Us",
      description: "A Saudi platform specialized in connecting you with certified technicians for all home maintenance services, quickly, safely, and easily. Our goal is to give you peace of mind and ensure quality for your home."
    },
    contact: {
      title: "Contact Us",
      description: "Our team is ready to receive your message and respond as quickly as possible. Fill in the details, and we will contact you directly to assist you or fulfill your request."
    },
    home: {
      title: "Tashyik | Book a certified home maintenance technician in Saudi Arabia",
      description: "Book trusted technicians for AC, plumbing, electrical, and appliance repair across every Saudi city. Fast service, certified warranty, transparent pricing."
    }
  },
  a11y: {
    open_user_menu: "Open user menu",
    open_main_menu: "Open main menu",
    close_menu: "Close menu",
    notifications: "Notifications",
    language: "Language",
    breadcrumb: "Breadcrumb",
    contact_whatsapp: "Contact us on WhatsApp",
    coupon_code: "Coupon code",
    show_password: "Show password",
    hide_password: "Hide password",
    chatbot: "Open chat"
  },
  common: {
    maintenance: "Maintenance",
    brand: "Tashyik",
    account: "Account",
    next: "Next",
    back: "Back",
    short_description: "Home Maintenance Services",
    order_service: "Request Service",
    load_more: "Load More",
    save: "Save",
    select_type: "Select Type",
    select_categories: "Select Categories",
    individual: "Individual",
    institution: "Institution",
    company: "Company",
    update: "Update",
    delete: "Delete",
    updated_successfully: "Updated Successfully",
    page_not_found: "Page Not Found",
    something_went_wrong: "Something went wrong",
    or: "Or",
    request_under_review: "Your request is under review",
    back_to_home: "Back to Home",
    no_price: "Price by agreement",
    select_city: "Select City",
    search_for_services: "Search for services...",
    search: "Search",
    promotion: "{percentage}% Off",
    warranty: "Warranty for {duration}",
    all: "All",
    wallet_balance: "Wallet Balance",
    optional: "Optional",
    select_address: "Select Address",
    done: "Done",
    loading: "Loading\u2026",
    order_now: "Order Now",
    send: "Send",
    close: "Close"
  },
  alt: {
    category: "{category} category",
    service: "{service} service"
  },
  home: {
    hero: {
      title: "Tashyik is now in Saudi Arabia!",
      subtitle: {
        part_1: "We are here",
        part_2: "To make your life easier",
        part_3: "All your home services in one place"
      },
      search_placeholder: "What service do you need?",
      search_button: "Search Now",
      rating_badge: "4.9 Customer Rating",
      response_badge: "Response in minutes",
      technicians_badge: "500+ Certified Techs",
      highlight_1: "Certified Technicians",
      highlight_2: "Response within minutes",
      description: "We provide you with integrated home maintenance services delivered to your doorstep quickly and easily.",
      actions: {
        browse_categories: "Browse Categories",
        request_custom_service: "Request Custom Service"
      }
    },
    categories: {
      title: "Categories",
      action: "View all categories",
      huge_discounts: "Huge Discounts"
    },
    offers: {
      title: "Exclusive Limited Time Offers",
      description: "Take advantage of the best discounts on home maintenance services with top professional technicians.",
      free_inspection: "Free Inspection",
      discount_on_service: "{percentage}% Off {name}",
      free_inspection_for: "Free Inspection for {name}",
      first_order_maintenance: "Home appliances maintenance from first order",
      plumbing_saving: "Plumbing savings"
    },
    top_rated: {
      title: "Top Rated",
      provider_1: {
        name: "Top AC Technician",
        title: "Air Conditioning Specialist"
      },
      provider_2: {
        name: "Top Electrician",
        title: "Electrical Repair Specialist"
      },
      provider_3: {
        name: "Top Appliance Technician",
        title: "Appliance Repair Specialist"
      }
    },
    features: {
      title: "Why choose Tashyik?",
      fast_support: {
        title: "Fast Support",
        description: "Our support team is available 24/7 to answer your questions and resolve your issues."
      },
      clear_prices: {
        title: "Clear Prices",
        description: "No hidden fees \u2014 prices are set in advance so you know the cost before booking."
      },
      trusted_techs: {
        title: "Trusted Technicians",
        description: "All technicians undergo thorough background checks and professional skills testing."
      },
      instant_booking: {
        title: "Instant Booking",
        description: "Just a few clicks and your technician is on the way to your home at the agreed time."
      },
      real_reviews: {
        title: "Real Reviews",
        description: "All reviews are from real customers who have already tried the service."
      },
      warranty: {
        title: "Service Warranty",
        description: "We provide a warranty of up to 30 days on all completed maintenance services."
      }
    },
    newsletter: {
      title: "Don't miss any new offer!",
      description: "Subscribe to our newsletter to receive the latest discounts and exclusive deals directly to your inbox.",
      placeholder: "Your email address",
      subscribe: "Subscribe"
    },
    collections: {
      view_all: "View all services",
      season_badge: "Season offer"
    },
    reviews: {
      title: "What our customers say!",
      item_1: {
        name: "Fahad Al-Anzi",
        tag: "AC Maintenance",
        body: "Excellent app! I requested an AC technician and he arrived within an hour. The work was clean and the price was very reasonable. Highly recommended! \u{1F44D}",
        date: "A week ago"
      },
      item_2: {
        name: "Sarah Al-Qahtani",
        tag: "Maintenance Support",
        body: "A wonderful experience! I contacted maintenance support and received quick responses and excellent help. The service exceeded expectations!",
        date: "Two days ago"
      },
      item_3: {
        name: "Mohammed Al-Sulaimani",
        tag: "Appliance Maintenance",
        body: "A distinguished application, the technicians are professional and fast. I fixed my AC in less than two hours. I advise everyone to try it!",
        date: "Yesterday"
      },
      item_4: {
        name: "Nasser Al-Otaibi",
        tag: "Electrical Maintenance",
        body: "Professional work and perfect timing. The technician explained the issue clearly and finished the service quickly while keeping the place clean. Thank you!",
        date: "Three days ago"
      }
    },
    questions: {
      title: "Questions you might have!"
    }
  },
  download_app: {
    title_1: "All your home services now..",
    title_2: "in one app!",
    subtitle: "Download the app and request the service you need at any time with complete comfort, all from your phone with a single click.",
    get_it_on: "Get it on",
    download_on_the: "Download on the",
    highlight_1: "Secure and guaranteed payment",
    highlight_2: "Request service in seconds",
    highlight_3: "Track technician real-time"
  },
  footer: {
    description_1: "Book a reliable home maintenance technician in minutes! We provide the best certified technicians in Saudi Arabia for electrical, plumbing, carpentry, and AC services, plus over ",
    description_2: "300 other services.",
    important_links: "Important Links",
    privacy_policy: "Privacy Policy",
    terms_and_conditions: "Terms & Conditions",
    faq: "FAQ",
    contact_us_link: "Contact Us",
    copyright: "All Rights Reserved",
    developed_by: "Executed by",
    developer: "Traffic Plus",
    contact_us: {
      title: "Contact Us",
      support: "Customer support available 24/7"
    },
    resources: "Important Links",
    download_app: "Download App",
    saudi_business_center: "Verified on Business Platform",
    popular_services: "Popular services",
    popular_cities: "Cities we serve",
    see_all_services: "See all services",
    see_all_cities: "See all cities"
  },
  navigation: {
    home: "Home",
    login: "Login",
    register: "Register",
    about: "About Us",
    categories: "Categories",
    services: "Services",
    download_app: "Download App",
    contact: "Contact Us",
    articles: "Articles",
    cities: "Cities",
    logout: "Logout",
    privacy_policy: "Privacy Policy",
    terms_and_conditions: "Terms and Conditions",
    service_provider: "Register as Service Provider",
    profile: {
      title: "My Account",
      subtitle: "Manage your personal info"
    },
    orders: {
      title: "My Orders",
      subtitle: "Track your orders and purchases"
    },
    addresses: {
      title: "My Addresses",
      subtitle: "Manage your saved addresses"
    },
    institution_members: {
      title: "Manage Employees",
      subtitle: "View and manage institution employees"
    }
  },
  guest: {
    login: {
      title: "Welcome!",
      subtitle: "Log in and complete your requests easily.",
      forgot_password: "Forgot your password?",
      sign_in: "Sign In",
      sign_up: "Create New Account",
      no_account: "Don't have an account?"
    },
    register: {
      customer: {
        title: "Create New Account",
        subtitle: "Create your account and request services easily."
      },
      service_provider: {
        title: "Create Your Account Now",
        subtitle: "Register as a technician and start receiving home maintenance requests now.",
        applied: {
          title: "Registered Successfully",
          subtitle: "Your registration request is currently under review."
        }
      },
      title: "Create New Account",
      create_account: "Create Account",
      have_account: "Already have an account?",
      sign_in: "Sign In"
    },
    forgot_password: {
      title: "Forgot Password?",
      subtitle: "Enter your email address and we will send you a verification code.",
      send_otp: "Send Verification Code",
      otp_subtitle: "Enter the verification code sent to your email.",
      otp_label: "Verification Code",
      verify_otp: "Verify Code",
      resend_otp: "Resend Code",
      success_message: "A verification code has been sent to your email.",
      back_to_login: "Back to Login"
    },
    reset_password: {
      title: "Reset Password",
      subtitle: "Enter your new password.",
      reset_button: "Reset Password",
      success_message: "Your password has been reset successfully. You can now log in with your new password."
    }
  },
  inputs: {
    email: "Email",
    email_optional: "Email (Optional)",
    name: "What is your name?",
    phone: "Phone Number",
    password: "Password",
    current_password: "Current Password",
    new_password: "New Password",
    password_confirmation: "Confirm Password",
    remember_me: "Remember Me",
    city: "Where do you live?",
    entity_type: "Account Type",
    categories: "Categories",
    residence_name: "Name on ID/Iqama",
    residence_number: "ID/Iqama Number",
    residence_image: "ID/Iqama Copy",
    commercial_registration_number: "CR Number",
    commercial_registration_image: "CR Copy",
    bank_name: "Bank Name",
    iban: "IBAN",
    personal_picture: "Profile Picture",
    national_address_image: "National Address Copy",
    tax_registration_number: "Tax Registration Number",
    address: {
      title: "Address",
      placeholder: "E.g., Riyadh Al Saliheen St, Mansoura, Riyadh"
    },
    type_address_name: {
      title: "Address Title",
      placeholder: "E.g., New Home"
    },
    landmark: {
      title: "Nearby Landmark",
      placeholder: "E.g., Next to the gas station"
    },
    address_name: "Address Name",
    building_number: "Building Number",
    floor_number: "Floor Number",
    apartment_number: "Apartment Number"
  },
  services: {
    index_eyebrow: "All services",
    index_title: "Find the right home service",
    index_subtitle: "Search across Tashyik services, filter by specialty, and book a certified technician without browsing categories first.",
    index_support_title: "Need help choosing the right service?",
    index_search_label: "Search services",
    index_search_placeholder: "Search by service name, problem, or keyword...",
    index_filter_by_category: "Filter by category",
    index_result_count: "Showing {count} of {total} services",
    index_clear_filters: "Clear filters",
    empty: {
      title: "No services found",
      subtitle: "Try changing the category or search terms to see more services"
    },
    invoice: {
      title: "View Invoice",
      service: "Service",
      service_price: "Service Price",
      visit_cost: "Visit Cost",
      subtotal: "Subtotal",
      tax: "Tax",
      wallet_balance: "Wallet Balance",
      total: "Total",
      pay: "Pay",
      request: "Request Service"
    },
    custom_service: {
      title: "Not sure about the right service?",
      subtitle: "Couldn't find exactly what you need? Don't worry! Describe the problem, and you'll receive quotes from specialized technicians.",
      action: "Request Custom Service"
    }
  },
  orders: {
    name: "My Orders",
    navigation: {
      new: "New",
      in_progress: "In Progress",
      completed: "Completed"
    },
    empty: {
      title: "No orders",
      subtitle: "No orders were found",
      view_services: "Request a service now"
    },
    make: {
      title: "Request Service",
      address: "Service Address",
      details: {
        title: "Service Details",
        description: "Problem description..."
      },
      coupons: {
        title: "Have a discount code?",
        placeholder: "Enter discount code",
        apply: "Apply"
      },
      summary: {
        title: "Order Summary"
      }
    }
  },
  notifications: {
    title: "Notifications",
    no_notifications: "No notifications"
  },
  addresses: {
    title: "My Addresses",
    heading: {
      title: "My Saved Addresses",
      subtitle: "Manage registered addresses or add new ones to request services quickly",
      action: "Add New Address"
    },
    new: {
      title: "Add New Address",
      subtitle: "Set your location on the map and make it easier for the technician to reach you"
    },
    create: {
      title: "Add Address",
      heading: {
        title: "Add New Address",
        subtitle: "Please select your location on the map and complete the details"
      },
      save: "Confirm Save Address"
    },
    edit: {
      title: "Edit Address",
      heading: {
        title: "Edit Address",
        subtitle: "Please select your location on the map and complete the details"
      },
      save: "Update Address"
    },
    form: {
      title: "Address Details",
      options: {
        home: "Home",
        work: "Work",
        other: "Other"
      }
    }
  },
  address: {
    details: "Building {building_number}, Apt {apartment_number}, Floor {floor_number}",
    mark_as_default: "Set as Default Address"
  },
  profile: {
    name: "Profile",
    header: {
      title: "Profile Settings",
      subtitle: "Change your profile settings, picture, and password."
    },
    information: "Profile Information",
    linked_institution: "Works at",
    update_password: "Update Password",
    delete_account: "Delete Account"
  },
  service_provider: {
    h1: {
      title: "Register with us as an AC, Electrical, Plumbing technician and more",
      description: "Do you have skills in home services and are looking for an easy way to reach customers? Join us and start providing your services with confidence and professionalism through our specialized platform."
    },
    h2: {
      title: "Provide your services now",
      description: "We welcome all technicians and home service providers in the following fields:",
      items: [
        "Air Conditioning (Installation \u2013 Maintenance \u2013 Cleaning)",
        "Electricity (Wiring \u2013 Repair \u2013 Appliance Installation)",
        "Plumbing (Maintenance \u2013 Leak Detection \u2013 Extensions)",
        "Home Appliances (Washers \u2013 Fridges \u2013 Ovens \u2013 Microwaves)",
        "Carpentry (Doors \u2013 Furniture \u2013 Bedrooms \u2013 Custom)",
        "Painting (Interior & Exterior \u2013 Wallpapers)",
        "Satellite (Installation \u2013 Programming \u2013 Maintenance)",
        "Home Cleaning (Comprehensive Cleaning \u2013 Facades \u2013 Carpets)",
        "Pest Control (Safe and Effective Pesticides)",
        "Home Assistance (Cleaning, Organizing, and Daily Support)"
      ]
    },
    button: "Register Now"
  },
  categories: {
    title: "All the maintenance services your home needs",
    subtitle: "Choose the right service and book a certified technician easily at any time.",
    banner: {
      title: "Ready to start your experience with Tashyik?",
      subtitle: "Download the Tashyik app now and get your first maintenance service with ease and professionalism."
    }
  },
  cities: {
    hero_title: "Trusted home maintenance in {city}",
    hero_h1_maintenance: "Home maintenance services in {city}",
    hero_compact_subtitle: "Certified technicians for AC, electrical, plumbing, and more \u2014 fast booking, dependable quality.",
    hero_subtitle: "Book certified technicians for AC, electrical, plumbing, appliances, and more \u2014 with quick response and guaranteed quality.",
    browse_services: "Browse services",
    schema_description: "Tashyik home maintenance coverage in {city}, Saudi Arabia.",
    popular_services: "Popular services in this city",
    available_in: "Available in",
    index_title: "Cities we serve",
    index_subtitle: "Pick a city to see popular home maintenance services and book certified technicians.",
    service_links_truncated: "Showing {shown} of {total} highlighted services in this list. Browse all categories for the full catalog.",
    view_city_hub: "All services in {city}",
    browse_by_city: "Browse by city",
    services_heading: "Services in {city}",
    services_search_label: "Search services",
    services_search_placeholder: "Search by service name\u2026",
    city_search_result_count: "Showing {filtered} results out of {total}",
    city_search_no_results_for: "No results for \xAB{q}\xBB",
    city_categories_filter_aria: "Filter services by category",
    districts_heading: "Districts of {city}",
    districts_intro: "We cover the main districts in {city} with fast arrival times.",
    services_results_range: "Showing {from}\u2013{to} of {total}",
    services_no_results: "No services match your search.",
    services_none_in_city: "No services are listed for this city yet.",
    pagination_label: "Service results pages",
    pagination_prev: "Previous",
    pagination_next: "Next",
    hero_cta_app: "Download the app",
    hero_cta_call: "Call us",
    price_currency: "SAR",
    index_browse_categories: "Browse all categories",
    index_filter_placeholder: "Filter cities\u2026",
    index_card_subtitle: "Home maintenance services",
    index_secondary_hint: "Prefer to browse by service type instead of city?",
    index_filter_no_match: "No cities match your filter.",
    service_in_city_cta_order: "Order this service",
    service_in_city_cta_order_now: "Order this service now",
    service_in_city_whatsapp_cta: "Contact us on WhatsApp",
    service_in_city_trust_secure_pay: "Secure, protected payments",
    service_in_city_certified_badge: "Certified technician",
    service_in_city_rating_line: "\u2B50 {rating} / 5 rating",
    service_in_city_rating_with_orders: "\u2B50 {rating} ({orders}+ orders)",
    service_in_city_social_hint: "Trusted customer experiences via the app and website",
    service_in_city_includes_title: "What does this service include?",
    service_in_city_local_overview: "Local overview for {city}",
    service_in_city_how_title: "How does it work?",
    service_in_city_how_step1: "Book",
    service_in_city_how_step1_desc: "Choose the service and a suitable time via the app or website.",
    service_in_city_how_step2: "Technician arrives",
    service_in_city_how_step2_desc: "A certified technician is dispatched to your address at the agreed time.",
    service_in_city_how_step3: "Enjoy the warranty",
    service_in_city_how_step3_desc: "Work is completed to quality standards with clear warranty coverage.",
    service_in_city_why_title: "Why Tashyik?",
    service_in_city_why_1_title: "Certified pros",
    service_in_city_why_1_desc: "We vet technicians and monitor service quality.",
    service_in_city_why_2_title: "Secure payments",
    service_in_city_why_2_desc: "Trusted payment options including Tabby and Tamara where applicable.",
    service_in_city_why_3_title: "Service warranty",
    service_in_city_why_3_desc: "Warranty duration is clearly stated before you confirm.",
    service_in_city_why_4_title: "Ongoing support",
    service_in_city_why_4_desc: "Our team follows your order through to completion.",
    service_in_city_reviews_title: "Customer reviews",
    service_in_city_rev1_name: "Mohammed A.",
    service_in_city_rev1_text: "Excellent experience \u2014 on time, tidy, professional work.",
    service_in_city_rev2_name: "Noura S.",
    service_in_city_rev2_text: "Clear pricing from the start; booking in the app was easy.",
    service_in_city_rev3_name: "Khalid M.",
    service_in_city_rev3_text: "Professional service; I recommend Tashyik for home maintenance.",
    service_in_city_default_bullet1: "On-site visit and assessment of the issue.",
    service_in_city_default_bullet2: "Repair or maintenance performed to safety standards.",
    service_in_city_default_bullet3: "Handover with notes and warranty details as applicable.",
    service_in_city_related_title: "More services in {city}",
    service_in_city_sidebar_summary: "Service & location",
    service_in_city_price_label: "From"
  },
  service: {
    order_service: "Order Service Now",
    actions: {
      order_now: "Order Now!",
      view_details: "View Details"
    },
    highlight_1: "Certified and Specialized Technicians",
    highlight_2: "Secure Payment",
    highlight_3: "Quality Guaranteed",
    highlights: {
      title: "What we will do for you?"
    }
  },
  order: {
    id: "Order Number",
    title: "Order Details",
    actions: {
      view_details: "View Order Details",
      rate: "Rate your experience",
      order_again: "Order Again",
      cancel: {
        title: "Cancel and Refund",
        description: "You must wait 15 minutes before you can cancel the order"
      }
    },
    summary: {
      title: "Order Summary",
      service: "Service",
      quantity: "Quantity",
      date: "Order Date",
      status: "Status",
      description: "Problem Description",
      visit_cost: "Visit Cost",
      subtotal: "Subtotal",
      tax: "Tax ({rate}%)",
      wallet_balance: "Wallet Balance",
      total: "Required Amount",
      pay: "Pay Now",
      confirm: "Confirm"
    },
    status: {
      title: "Order Status",
      new: "Showing to technicians",
      confirmed: "Confirmed",
      on_the_way: "Technician is on the way",
      arrived: "Technician has arrived",
      started: "Work in progress",
      completed: "Completed"
    },
    service_provider: {
      title: "Technician",
      phone: "Phone",
      actions: {
        view_on_map: "View on Map",
        call: "Call Technician",
        whatsapp: "Message on WhatsApp"
      }
    },
    invoice: {
      title: "Invoice Details",
      price: "Service Price",
      tax: "VAT ({rate}%)",
      total: "Total",
      view_details: "View Details",
      hide_details: "Hide Details",
      visit_cost: "Visit Cost",
      coupons: "Discount Codes",
      wallet_balance: "Wallet Balance"
    },
    canceled: {
      title: "Order Canceled",
      subtitle: "The amount has been added back to your wallet balance"
    },
    extra: {
      title: "Extra Services",
      unpaid: "Unpaid",
      paid: "Paid",
      view_details: "View Details",
      invoice: {
        title: "Extra Service Details",
        price: "Extra Service Price",
        tax: "Extra Service Tax",
        materials: "Materials Price"
      }
    }
  },
  review: {
    title: "Service Rating",
    price: "Cost",
    rate: "How was your overall experience?",
    notes: "Write your notes (optional)",
    notes_placeholder: "Write your notes or suggestions here...",
    actions: {
      send: "Send Rating",
      skip: "Skip"
    }
  },
  about: {
    hero: {
      title: "Tashyik \u2013 Serving you with professionalism",
      description: "A Saudi platform specialized in connecting you with certified technicians for all home maintenance services, quickly, safely, and easily. Our goal is to provide peace of mind and ensure quality that suits your home.",
      subtitle: {
        part_1: "Who",
        part_2: "Are we?"
      },
      actions: {
        discover: "Discover Our Story"
      },
      highlight: {
        title: "Full Reliability",
        subtitle: "Technicians with National ID"
      }
    },
    story: {
      title: "Our Story",
      paragraph_1: "We started Tashyik with the aim of simplifying people\u2019s lives and providing a smart solution that gathers all home maintenance services in one place. We believe that fast and reliable service begins with choosing the right technician and ends with customer satisfaction.",
      paragraph_2: "Our vision goes beyond just fixing faults; we seek to build a Saudi technical community that contributes to raising the quality of life inside every home in the Kingdom, by organizing maintenance services and providing them through a single application, while raising professional standards."
    },
    features: {
      title: {
        part_1: "Why choose",
        part_2: "Tashyik?"
      },
      subtitle: "We are not just a maintenance app! We are your trusted partner for home care.",
      feature_1: {
        title: "Certified Technicians",
        description: "We select technicians carefully and review their performance constantly to ensure the highest level of quality."
      },
      feature_2: {
        title: "Fast Response",
        description: "The nearest technician reaches you in record time to solve your problem as quickly as possible."
      },
      feature_3: {
        title: "Secure Payment",
        description: "Trusted and protected payment methods with the latest electronic security standards."
      },
      feature_4: {
        title: "Real-time Tracking",
        description: "Follow your order status step-by-step through the application with full transparency."
      }
    },
    stats_1: {
      title: "3,800+",
      subtitle: "Certified Professional Technicians"
    },
    stats_2: {
      title: "632,000+",
      subtitle: "Successfully Executed Orders"
    },
    stats_3: {
      title: "4.8",
      subtitle: "Customer Satisfaction Rating"
    },
    audience: {
      title: "Who do we serve?",
      subtitle: "Whether you need quick maintenance, installation, or repair, Tashyik serves you and fits your needs.",
      individuals: {
        title: "Homeowners",
        description: "We serve homeowners who want peace of mind and don\u2019t have time to look for a technician or try multiple times. Through our platform, you can request the maintenance service you need easily, and we connect you with reliable technicians who get the job done professionally and on time, so your home always stays in its best condition."
      },
      institutions: {
        title: "Institutions",
        description: "We know that any minor fault can affect the workflow. That\u2019s why we provide institutions with maintenance solutions that help them maintain business continuity without interruption, whether it\u2019s periodic maintenance or urgent requests. We care about organization, commitment, and quality of execution every time."
      },
      service_providers: {
        title: "Technicians",
        description: "We believe the technician is the heart of the service and the basis of its success. We provide technicians with a platform that helps them reach real customers, clear order organization, and support that facilitates their daily work. Our goal is for the technician to focus on his work and grow with us step by step with confidence and stability."
      }
    }
  },
  contact: {
    title: "Contact Us Directly",
    subtitle: "Our team is ready to serve you and answer all your inquiries",
    hero: {
      title: "Welcome! How can we help you?",
      description: "Our team is ready to receive your message and respond as quickly as possible. Fill in the details, and we will contact you directly to help you or fulfill your request."
    },
    inputs: {
      name: {
        title: "Full Name",
        placeholder: "Enter your full name"
      },
      subject: {
        title: "What do you want to talk about?",
        placeholder: "Maintenance, inquiry, complaint, or anything else"
      },
      message: {
        title: "Tell us what\u2019s on your mind!",
        placeholder: "Write your message here and we will respond as soon as possible..."
      }
    },
    actions: {
      send: "Send Your Message"
    },
    info: {
      whatsapp: "Message us on WhatsApp",
      phone: "Call us immediately",
      email: "Email us"
    },
    more_info: {
      title: "Comprehensive Coverage",
      subtitle: "Serving you in all regions of Saudi Arabia with full professionalism!"
    },
    map: {
      title: "Our Location",
      subtitle: "Visit us at our headquarters in Riyadh"
    },
    message_sent: "Sent Successfully"
  },
  articles: {
    seo: {
      title: "Articles - Tashyik",
      description: "Read the latest articles and tips about home maintenance, appliance care, and best practices to keep your home in great shape."
    },
    hero: {
      title: "Articles",
      subtitle: "Useful tips and information about home maintenance and caring for your home"
    },
    featured_badge: "Featured",
    read_more: "Read More",
    share: "Share Article",
    empty: "No articles available",
    related: "Related Articles"
  },
  institution: {
    title: "Manage Employees",
    subtitle: "View performance and statistics of institution employees",
    seo_title: "Manage Employees",
    summary: {
      active_members: "Active Employees",
      this_month_orders: "Orders This Month",
      this_month_earnings: "Earnings This Month",
      balance: "Current Balance"
    },
    member: {
      total_orders: "Total Orders",
      completed_orders: "Completed Orders",
      this_month: "This Month",
      earnings: "Earnings",
      joined: "Joined"
    },
    empty: {
      title: "No employees",
      subtitle: "No employees have been added to the institution yet. Contact admin to add employees."
    },
    status: {
      active: "Active",
      pending: "Pending",
      inactive: "Inactive"
    },
    filter: {
      all: "All",
      search: "Search by name or phone...",
      results: "{count} results",
      no_results: "No results found",
      clear: "Clear filters"
    },
    sort: {
      name: "Sort by name",
      earnings: "Highest earnings",
      orders: "Most orders",
      this_month: "Most active this month"
    }
  },
  chatbot: {
    title: "Tashyik Chat",
    subtitle: "We are here to help you",
    welcome: "Welcome! How can we help you?",
    placeholder: "Type your message...",
    new_chat: "New Chat",
    send: "Send",
    close: "Close",
    typing: "Typing...",
    error_network: "Unable to connect. Please check your connection and try again.",
    error_server: "Server error occurred. Please try again later.",
    error_generic: "An unexpected error occurred. Please try again.",
    retry: "Try again",
    messages_count: "messages",
    suggestion_1: "Example: Can I book a fast electrician service?",
    suggestion_2: "Example: How do I request AC maintenance?"
  }
};

export { en as default };
//# sourceMappingURL=en.mjs.map
