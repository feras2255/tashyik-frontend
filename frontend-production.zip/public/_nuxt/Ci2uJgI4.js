import{_ as e}from"#entry";function _(t){e(()=>import("./BCl_qhkn.js"),[],import.meta.url).then(o=>{t(o)})}export{_ as u};
