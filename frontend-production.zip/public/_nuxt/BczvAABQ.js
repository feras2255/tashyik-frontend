function i(){function o(){window.$zoho?.salesiq&&($zoho.salesiq.floatwindow.visible("show"),$zoho.salesiq.chatwindow.open())}return{openChat:o}}export{i as u};
