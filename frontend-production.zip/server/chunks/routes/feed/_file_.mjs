import { c as defineEventHandler, u as useRuntimeConfig, e as createError } from '../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@intlify/utils';
import 'vue-router';
import 'node:url';

const _file_ = defineEventHandler(async (event) => {
  const config = useRuntimeConfig();
  event.node.res.setHeader("Content-Type", "application/xml");
  try {
    const file = await $fetch(`${config.public.apiBaseUrl}/feed/${event.context.params.file}`, {
      headers: {
        Accept: "application/json"
      }
    });
    return file;
  } catch (error) {
    throw createError({
      statusCode: 404,
      message: "Page Not Found",
      fatal: true
    });
  }
});

export { _file_ as default };
//# sourceMappingURL=_file_.mjs.map
