import { c as defineEventHandler, p as proxyRequest } from '../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@intlify/utils';
import 'vue-router';
import 'node:url';

const _____ = defineEventHandler(async (event) => {
  const url = new URL(event.node.req.url, "http://localhost");
  const path = url.pathname.replace(/^\/__api/, "") + url.search;
  const target = `http://127.0.0.1:8000${path}`;
  return proxyRequest(event, target, {
    headers: {
      Host: "api.localhost:8000"
    }
  });
});

export { _____ as default };
//# sourceMappingURL=_..._.mjs.map
