const fr = {
  seo: {
    login: {
      title: "Connexion"
    },
    register: {
      title: "Cr\xE9er un compte"
    },
    service_provider_register: {
      title: "Cr\xE9er un compte prestataire"
    },
    orders: {
      title: "Mes commandes",
      view: {
        title: "D\xE9tails de la commande"
      }
    },
    addresses: {
      title: "Mes adresses",
      create: {
        title: "Ajouter une nouvelle adresse"
      },
      edit: {
        title: "Modifier l'adresse"
      }
    },
    profile: {
      title: "Profil personnel"
    },
    forgot_password: {
      title: "Mot de passe oubli\xE9"
    },
    reset_password: {
      title: "R\xE9initialiser le mot de passe"
    },
    service_provider: {
      title: "Rejoignez-nous en tant que technicien",
      description: "Inscrivez-vous en tant que prestataire de services \xE0 domicile et proposez vos services de climatisation, \xE9lectricit\xE9, plomberie, \xE9lectrom\xE9nager, menuiserie, peinture, satellite, nettoyage, lutte contre les nuisibles et aide \xE0 domicile en toute s\xE9curit\xE9."
    },
    categories: {
      title: "Cat\xE9gories",
      description: "Parcourez les cat\xE9gories de services de maintenance \xE0 domicile : plomberie, \xE9lectricit\xE9, climatisation et r\xE9paration d'appareils. R\xE9servez rapidement un technicien certifi\xE9."
    },
    about: {
      title: "\xC0 propos de nous",
      description: "Une plateforme saoudienne sp\xE9cialis\xE9e pour vous connecter \xE0 des techniciens certifi\xE9s pour tous vos services de maintenance, rapidement et en toute s\xE9curit\xE9. Notre objectif : votre tranquillit\xE9 d'esprit."
    },
    contact: {
      title: "Contactez-nous",
      description: "Notre \xE9quipe est pr\xEAte \xE0 recevoir votre message et \xE0 vous r\xE9pondre dans les plus brefs d\xE9lais. Remplissez vos coordonn\xE9es et nous vous contacterons directement."
    }
  },
  common: {
    brand: "Tashyik",
    account: "Compte",
    next: "Suivant",
    back: "Retour",
    short_description: "Services de maintenance \xE0 domicile",
    order_service: "Commander un service",
    load_more: "Charger plus",
    save: "Enregistrer",
    select_type: "S\xE9lectionner le type",
    select_categories: "S\xE9lectionner les cat\xE9gories",
    individual: "Individuel",
    institution: "Institution",
    company: "Entreprise",
    update: "Mettre \xE0 jour",
    delete: "Supprimer",
    updated_successfully: "Mis \xE0 jour avec succ\xE8s",
    page_not_found: "Page non trouv\xE9e",
    or: "Ou",
    request_under_review: "Votre demande est en cours de r\xE9vision",
    back_to_home: "Retour \xE0 l'accueil",
    no_price: "Prix par accord",
    select_city: "S\xE9lectionner la ville",
    search_for_services: "Rechercher des services...",
    search: "Recherche",
    promotion: "{percentage}% de r\xE9duction",
    warranty: "Garantie de {duration}",
    all: "Tout",
    wallet_balance: "Solde du portefeuille",
    optional: "Optionnel",
    select_address: "S\xE9lectionner l'adresse",
    done: "Termin\xE9"
  },
  alt: {
    category: "Cat\xE9gorie {category}",
    service: "Service {service}"
  },
  home: {
    hero: {
      title: "Tashyik est maintenant en Arabie Saoudite !",
      subtitle: {
        part_1: "Nous sommes l\xE0",
        part_2: "Pour vous faciliter la vie"
      },
      highlight_1: "Techniciens certifi\xE9s",
      highlight_2: "R\xE9ponse en quelques minutes",
      description: "Nous vous offrons des services de maintenance \xE0 domicile int\xE9gr\xE9s, livr\xE9s \xE0 votre porte rapidement et facilement.",
      actions: {
        browse_categories: "Parcourir les cat\xE9gories",
        request_custom_service: "Demander un service personnalis\xE9"
      }
    },
    categories: {
      title: "Tout ce dont vous avez besoin est ici !",
      action: "Voir toutes les cat\xE9gories"
    },
    features: {
      title: "Pourquoi des milliers de clients nous font confiance ?",
      subtitle: "Nous sommes fiers de la confiance de nos clients car nous nous effor\xE7ons toujours de fournir un service fiable.",
      feature_1: {
        title: "+300",
        description: "Services \xE0 domicile"
      },
      feature_2: {
        title: "3 800+",
        description: "Techniciens professionnels"
      },
      feature_3: {
        title: "632 000+",
        description: "Services termin\xE9s"
      },
      feature_4: {
        title: "25+",
        description: "Villes couvertes"
      },
      feature_5: {
        title: "4.8",
        description: "Note moyenne des clients"
      }
    },
    reviews: {
      title: "Ce que disent nos clients !",
      item_1: {
        name: "Fahad Al-Anzi",
        body: "Excellente application ! J'ai demand\xE9 un technicien AC et il est arriv\xE9 en moins d'une heure. Travail propre et prix raisonnable. Je recommande vivement ! \u{1F44D}",
        date: "Il y a une semaine"
      },
      item_2: {
        name: "Sarah Al-Qahtani",
        body: "Une exp\xE9rience merveilleuse ! Le support a \xE9t\xE9 tr\xE8s r\xE9actif. Le service a d\xE9pass\xE9 mes attentes !",
        date: "Il y a deux jours"
      },
      item_3: {
        name: "Mohammed Al-Sulaimani",
        body: "Application distingu\xE9e, techniciens professionnels. J'ai r\xE9par\xE9 ma clim en moins de deux heures.",
        date: "Hier"
      }
    },
    questions: {
      title: "Questions fr\xE9quentes"
    }
  },
  download_app: {
    title: "Tous vos services \xE0 domicile.. en une seule appli !",
    subtitle: "T\xE9l\xE9chargez l'application et demandez le service dont vous avez besoin en un seul clic.",
    get_it_on: "Disponible sur",
    download_on_the: "T\xE9l\xE9charger sur",
    highlight_1: "Demande de service en quelques secondes",
    highlight_2: "Paiement s\xE9curis\xE9 et garanti",
    highlight_3: "Suivi du technicien en temps r\xE9el"
  },
  footer: {
    copyright: "Tous droits r\xE9serv\xE9s",
    developed_by: "R\xE9alis\xE9 par",
    developer: "Traffic Plus",
    contact_us: {
      title: "Contactez-nous",
      support: "Support client disponible 24/7"
    },
    resources: "Liens importants",
    download_app: "T\xE9l\xE9charger l'application",
    saudi_business_center: "V\xE9rifi\xE9 par Business Platform"
  },
  navigation: {
    home: "Accueil",
    login: "Connexion",
    register: "Inscription",
    about: "\xC0 propos",
    categories: "Cat\xE9gories",
    download_app: "T\xE9l\xE9charger l'appli",
    contact: "Contact",
    logout: "D\xE9connexion",
    privacy_policy: "Politique de confidentialit\xE9",
    terms_and_conditions: "Conditions g\xE9n\xE9rales",
    service_provider: "Devenir prestataire",
    profile: {
      title: "Mon compte",
      subtitle: "G\xE9rer mes infos personnelles"
    },
    orders: {
      title: "Mes commandes",
      subtitle: "Suivre mes commandes"
    },
    addresses: {
      title: "Mes adresses",
      subtitle: "G\xE9rer les adresses enregistr\xE9es"
    }
  },
  guest: {
    login: {
      title: "Bienvenue !",
      subtitle: "Connectez-vous pour compl\xE9ter vos demandes.",
      forgot_password: "Mot de passe oubli\xE9 ?",
      sign_in: "Se connecter",
      sign_up: "Cr\xE9er un compte",
      no_account: "Pas encore de compte ?"
    },
    register: {
      customer: {
        title: "Cr\xE9er un nouveau compte",
        subtitle: "Cr\xE9ez votre compte et commandez vos services facilement."
      },
      service_provider: {
        title: "Devenir technicien",
        subtitle: "Inscrivez-vous et commencez \xE0 recevoir des demandes de maintenance.",
        applied: {
          title: "Inscription r\xE9ussie",
          subtitle: "Votre demande est en cours de r\xE9vision."
        }
      },
      title: "Inscription",
      create_account: "Cr\xE9er un compte",
      have_account: "D\xE9j\xE0 inscrit ?",
      sign_in: "Se connecter"
    },
    forgot_password: {
      title: "Mot de passe oubli\xE9 ?",
      subtitle: "Entrez votre adresse e-mail et nous vous enverrons un code de v\xE9rification.",
      send_otp: "Envoyer le code",
      otp_subtitle: "Entrez le code de v\xE9rification envoy\xE9 \xE0 votre e-mail.",
      otp_label: "Code de v\xE9rification",
      verify_otp: "V\xE9rifier le code",
      resend_otp: "Renvoyer le code",
      success_message: "Un code de v\xE9rification a \xE9t\xE9 envoy\xE9 \xE0 votre e-mail.",
      back_to_login: "Retour \xE0 la connexion"
    },
    reset_password: {
      title: "R\xE9initialiser le mot de passe",
      subtitle: "Entrez votre nouveau mot de passe.",
      reset_button: "R\xE9initialiser",
      success_message: "Mot de passe r\xE9initialis\xE9 avec succ\xE8s. Vous pouvez maintenant vous connecter."
    }
  },
  inputs: {
    email: "E-mail",
    email_optional: "E-mail (Optionnel)",
    name: "Quel est votre nom ?",
    phone: "Num\xE9ro de t\xE9l\xE9phone",
    password: "Mot de passe",
    current_password: "Mot de passe actuel",
    new_password: "Nouveau mot de passe",
    password_confirmation: "Confirmer le mot de passe",
    remember_me: "Se souvenir de moi",
    city: "O\xF9 habitez-vous ?",
    entity_type: "Type de compte",
    categories: "Cat\xE9gories",
    residence_name: "Nom sur la carte d'identit\xE9/Iqama",
    residence_number: "Num\xE9ro d'identit\xE9/Iqama",
    residence_image: "Copie de l'identit\xE9/Iqama",
    commercial_registration_number: "Num\xE9ro de registre du commerce",
    commercial_registration_image: "Copie du registre du commerce",
    bank_name: "Nom de la banque",
    iban: "IBAN",
    personal_picture: "Photo de profil",
    national_address_image: "Copie de l'adresse nationale",
    tax_registration_number: "Num\xE9ro d'enregistrement fiscal",
    address: {
      title: "Adresse",
      placeholder: "Ex: Rue Riyadh Al Saliheen, Mansoura, Riyad"
    },
    type_address_name: {
      title: "Titre de l'adresse",
      placeholder: "Ex: Maison neuve"
    },
    landmark: {
      title: "Point de rep\xE8re",
      placeholder: "Ex: Pr\xE8s de la station essence"
    },
    address_name: "Nom de l'adresse",
    building_number: "Num\xE9ro d'immeuble",
    floor_number: "\xC9tage",
    apartment_number: "Num\xE9ro d'appartement"
  },
  services: {
    empty: {
      title: "Aucun service trouv\xE9",
      subtitle: "Essayez de modifier la cat\xE9gorie ou les termes de recherche."
    },
    invoice: {
      title: "Voir la facture",
      service: "Service",
      service_price: "Prix du service",
      visit_cost: "Frais de visite",
      subtotal: "Sous-total",
      tax: "Taxes",
      wallet_balance: "Solde du portefeuille",
      total: "Total",
      pay: "Payer",
      request: "Commander le service"
    },
    custom_service: {
      title: "Besoin d'un service sp\xE9cifique ?",
      subtitle: "D\xE9crivez votre probl\xE8me et recevez des devis de techniciens sp\xE9cialis\xE9s.",
      action: "Demander un service personnalis\xE9"
    }
  },
  orders: {
    name: "Mes commandes",
    navigation: {
      new: "Nouvelles",
      in_progress: "En cours",
      completed: "Termin\xE9es"
    },
    empty: {
      title: "Aucune commande",
      subtitle: "Vous n'avez pas encore de commande.",
      view_services: "Commander un service maintenant"
    },
    make: {
      title: "Demander un service",
      address: "Adresse du service",
      details: {
        title: "D\xE9tails du service",
        description: "Description du probl\xE8me..."
      },
      coupons: {
        title: "Avez-vous un code promo ?",
        placeholder: "Entrez le code",
        apply: "Appliquer"
      },
      summary: {
        title: "R\xE9sum\xE9 de la commande"
      }
    }
  },
  notifications: {
    title: "Notifications",
    no_notifications: "Aucune notification"
  },
  addresses: {
    title: "Mes adresses",
    heading: {
      title: "Mes adresses enregistr\xE9es",
      subtitle: "G\xE9rez vos adresses ou ajoutez-en une nouvelle.",
      action: "Ajouter une adresse"
    },
    new: {
      title: "Nouvelle adresse",
      subtitle: "D\xE9finissez votre position sur la carte pour aider le technicien."
    },
    create: {
      title: "Ajouter une adresse",
      heading: {
        title: "Nouvelle adresse",
        subtitle: "Veuillez s\xE9lectionner votre position sur la carte."
      },
      save: "Confirmer l'enregistrement"
    },
    edit: {
      title: "Modifier l'adresse",
      heading: {
        title: "Modifier l'adresse",
        subtitle: "Veuillez mettre \xE0 jour votre position sur la carte."
      },
      save: "Mettre \xE0 jour l'adresse"
    },
    form: {
      title: "D\xE9tails de l'adresse",
      options: {
        home: "Domicile",
        work: "Travail",
        other: "Autre"
      }
    }
  },
  address: {
    details: "Immeuble {building_number}, Appt {apartment_number}, \xC9tage {floor_number}",
    mark_as_default: "D\xE9finir comme adresse par d\xE9faut"
  },
  profile: {
    name: "Profil",
    header: {
      title: "Param\xE8tres du profil",
      subtitle: "Modifiez vos param\xE8tres, photo et mot de passe."
    },
    information: "Informations personnelles",
    update_password: "Mettre \xE0 jour le mot de passe",
    delete_account: "Supprimer le compte"
  },
  service_provider: {
    h1: {
      title: "Inscrivez-vous comme technicien AC, \xC9lectricit\xE9, Plomberie et plus",
      description: "Vous avez des comp\xE9tences en maintenance ? Rejoignez notre plateforme et commencez \xE0 recevoir des clients avec professionnalisme."
    },
    h2: {
      title: "Offrez vos services d\xE8s maintenant",
      description: "Nous accueillons les experts dans les domaines suivants :",
      items: ["Climatisation", "\xC9lectricit\xE9", "Plomberie", "\xC9lectrom\xE9nager", "Menuiserie", "Peinture", "Satellite", "Nettoyage", "Lutte contre les nuisibles", "Aide \xE0 domicile"]
    },
    button: "S'inscrire maintenant"
  },
  categories: {
    title: "Tous les services de maintenance pour votre maison",
    subtitle: "Choisissez le service appropri\xE9 et r\xE9servez un technicien certifi\xE9.",
    banner: {
      title: "Pr\xEAt \xE0 commencer avec Tashyik ?",
      subtitle: "T\xE9l\xE9chargez l'appli maintenant et facilitez la maintenance de votre maison."
    }
  },
  service: {
    order_service: "Commander le service maintenant",
    actions: {
      order_now: "Commander !",
      view_details: "Voir les d\xE9tails"
    },
    highlight_1: "Techniciens certifi\xE9s et sp\xE9cialis\xE9s",
    highlight_2: "Paiement s\xE9curis\xE9",
    highlight_3: "Qualit\xE9 garantie",
    highlights: {
      title: "Que ferons-nous pour vous ?"
    }
  },
  order: {
    id: "Num\xE9ro de commande",
    title: "D\xE9tails de la commande",
    actions: {
      view_details: "Voir les d\xE9tails",
      rate: "\xC9valuer l'exp\xE9rience",
      order_again: "Commander \xE0 nouveau",
      cancel: {
        title: "Annuler et rembourser",
        description: "Attendez 15 minutes avant d'annuler la commande."
      }
    },
    summary: {
      title: "R\xE9sum\xE9",
      service: "Service",
      quantity: "Quantit\xE9",
      date: "Date",
      status: "Statut",
      description: "Description",
      visit_cost: "Visite",
      subtotal: "Sous-total",
      tax: "Taxe ({rate}%)",
      wallet_balance: "Portefeuille",
      total: "Total \xE0 payer",
      pay: "Payer maintenant",
      confirm: "Confirmer"
    },
    status: {
      title: "Statut de la commande",
      new: "Visible par les techniciens",
      confirmed: "Confirm\xE9e",
      on_the_way: "Technicien en chemin",
      arrived: "Technicien arriv\xE9",
      started: "Travaux en cours",
      completed: "Termin\xE9e"
    },
    service_provider: {
      title: "Technicien",
      phone: "T\xE9l\xE9phone",
      actions: {
        view_on_map: "Voir sur la carte",
        call: "Appeler",
        whatsapp: "WhatsApp"
      }
    },
    invoice: {
      title: "Facture",
      price: "Prix service",
      tax: "TVA ({rate}%)",
      total: "Total",
      view_details: "Voir plus",
      hide_details: "Masquer",
      visit_cost: "Frais visite",
      coupons: "Codes promo",
      wallet_balance: "Solde utilis\xE9"
    },
    canceled: {
      title: "Commande annul\xE9e",
      subtitle: "Le montant a \xE9t\xE9 rembours\xE9 sur votre portefeuille."
    },
    extra: {
      title: "Services suppl\xE9mentaires",
      unpaid: "Non pay\xE9",
      paid: "Pay\xE9",
      view_details: "Voir d\xE9tails",
      invoice: {
        title: "D\xE9tails extra",
        price: "Prix service extra",
        tax: "Taxe extra",
        materials: "Prix mat\xE9riaux"
      }
    }
  },
  review: {
    title: "\xC9valuation",
    price: "Co\xFBt",
    rate: "Quelle est votre satisfaction globale ?",
    notes: "Remarques (optionnel)",
    notes_placeholder: "Vos suggestions...",
    actions: {
      send: "Envoyer",
      skip: "Passer"
    }
  },
  about: {
    hero: {
      title: "Tashyik \u2013 Servir avec professionnalisme",
      description: "Plateforme saoudienne connectant particuliers et techniciens pour une maintenance s\xFBre et rapide.",
      subtitle: {
        part_1: "Qui",
        part_2: "Sommes-nous ?"
      },
      actions: {
        discover: "D\xE9couvrir notre histoire"
      },
      highlight: {
        title: "Fiabilit\xE9 totale",
        subtitle: "Techniciens v\xE9rifi\xE9s"
      }
    },
    story: {
      title: "Notre Histoire",
      paragraph_1: "Tashyik est n\xE9e de la volont\xE9 de simplifier la vie quotidienne en centralisant les services de maintenance.",
      paragraph_2: "Nous aspirons \xE0 cr\xE9er une communaut\xE9 technique saoudienne de haute qualit\xE9."
    },
    features: {
      title: {
        part_1: "Pourquoi",
        part_2: "Tashyik ?"
      },
      subtitle: "Plus qu'une application, un partenaire de confiance pour votre maison.",
      feature_1: {
        title: "Experts Certifi\xE9s",
        description: "Une s\xE9lection rigoureuse pour garantir l'excellence."
      },
      feature_2: {
        title: "R\xE9ponse Rapide",
        description: "Le technicien le plus proche intervient en un temps record."
      },
      feature_3: {
        title: "Paiement S\xFBr",
        description: "M\xE9thodes de paiement prot\xE9g\xE9es par les derniers standards."
      },
      feature_4: {
        title: "Suivi R\xE9el",
        description: "Transparence totale sur l'\xE9tat de votre demande."
      }
    },
    stats_1: {
      title: "3 800+",
      subtitle: "Experts Certifi\xE9s"
    },
    stats_2: {
      title: "632 000+",
      subtitle: "Services R\xE9alis\xE9s"
    },
    stats_3: {
      title: "4.8",
      subtitle: "Satisfaction Client"
    },
    audience: {
      title: "Qui servons-nous ?",
      subtitle: "Tashyik s'adapte \xE0 tous vos besoins de maintenance.",
      individuals: {
        title: "Propri\xE9taires",
        description: "Pour ceux qui veulent la paix d'esprit sans perdre de temps."
      },
      institutions: {
        title: "\xC9tablissements",
        description: "Solutions pour garantir la continuit\xE9 de vos activit\xE9s."
      },
      service_providers: {
        title: "Techniciens",
        description: "Le c\u0153ur de notre service. Nous valorisons votre travail."
      }
    }
  },
  contact: {
    title: "Contactez-nous",
    subtitle: "Notre \xE9quipe est \xE0 votre \xE9coute",
    hero: {
      title: "Bonjour ! Comment aider ?",
      description: "Remplissez le formulaire et nous reviendrons vers vous."
    },
    inputs: {
      name: {
        title: "Nom complet",
        placeholder: "Votre nom"
      },
      subject: {
        title: "Sujet",
        placeholder: "Maintenance, demande, r\xE9clamation..."
      },
      message: {
        title: "Votre message",
        placeholder: "Dites-nous tout..."
      }
    },
    actions: {
      send: "Envoyer le message"
    },
    info: {
      whatsapp: "WhatsApp",
      phone: "Appeler",
      email: "E-mail"
    },
    more_info: {
      title: "Couverture globale",
      subtitle: "Pr\xE9sents dans toutes les r\xE9gions d'Arabie Saoudite !"
    },
    map: {
      title: "Notre emplacement",
      subtitle: "Visitez notre si\xE8ge \xE0 Riyad"
    },
    message_sent: "Envoy\xE9 avec succ\xE8s"
  }
};

export { fr as default };
//# sourceMappingURL=fr.mjs.map
